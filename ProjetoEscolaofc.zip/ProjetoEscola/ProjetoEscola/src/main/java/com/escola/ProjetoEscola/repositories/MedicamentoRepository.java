package com.escola.ProjetoEscola.repositories;

import com.escola.ProjetoEscola.models.Medicamento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface MedicamentoRepository extends JpaRepository<Medicamento, Long> {

    List<Medicamento> findByNomeContaining(String nome);

    List<Medicamento> findByLaboratorio(String laboratorio);

    List<Medicamento> findByDataValidadeBefore(LocalDate data);
}