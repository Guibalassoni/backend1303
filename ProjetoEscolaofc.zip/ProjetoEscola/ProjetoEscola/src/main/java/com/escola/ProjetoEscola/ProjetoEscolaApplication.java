package com.escola.ProjetoEscola;

import com.escola.ProjetoEscola.models.Curso;
import com.escola.ProjetoEscola.repositories.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class ProjetoEscolaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoEscolaApplication.class, args);
    }

    @Bean
    public CommandLineRunner init(@Autowired CursoRepository cursoRepository) {
        return args -> {
            Curso curso1 = new Curso();
            curso1.setNome("teste");
            curso1.setCargaHoraria(2000);
            cursoRepository.inserir(curso1);

            Curso curso2 = new Curso();
            curso2.setNome("teste2");
            curso2.setCargaHoraria(2050);
            cursoRepository.inserir(curso2);

            List<Curso> listaCursos = cursoRepository.obterTodos();
            listaCursos.forEach(System.out::println);
        };

        @Bean
        public CommandLineRunner testCategoriaCursoRepository(@Autowired CategoriaCursoRepository categoriaCursoRepository) {
            return args -> {
                // Teste inserir
                CategoriaCurso categoria1 = new CategoriaCurso();
                categoria1.setNome("Programação");
                categoriaCursoRepository.inserir(categoria1);
    
                CategoriaCurso categoria2 = new CategoriaCurso();
                categoria2.setNome("Design");
                categoriaCursoRepository.inserir(categoria2);
    
                // Teste obterTodos
                List<CategoriaCurso> categorias = categoriaCursoRepository.obterTodos();
                System.out.println("Categorias: " + categorias);
    
                // Teste obterPorNome
                List<CategoriaCurso> categoriasPorNome = categoriaCursoRepository.obterPorNome("Prog");
                System.out.println("Categorias por nome: " + categoriasPorNome);
    
                // Teste editar
                categoria1.setNome("Programação Web");
                categoriaCursoRepository.editar(categoria1);
                System.out.println("Categoria editada: " + categoriaCursoRepository.obterTodos());
    
                // Teste excluir por ID
                categoriaCursoRepository.excluir(categoria2.getId());
                System.out.println("Categoria excluída por ID: " + categoriaCursoRepository.obterTodos());
    
                // Teste excluir por objeto
                categoriaCursoRepository.excluir(categoria1);
                System.out.println("Categoria excluída por objeto: " + categoriaCursoRepository.obterTodos());
            };
        }
    }
}