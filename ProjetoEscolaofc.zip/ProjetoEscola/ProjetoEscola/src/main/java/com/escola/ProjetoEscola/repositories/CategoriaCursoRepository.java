package com.escola.ProjetoEscola.repositories;

import com.escola.ProjetoEscola.models.CategoriaCurso;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class CategoriaCursoRepository {

    @Autowired
    private EntityManager entityManager;

    public List<CategoriaCurso> obterTodos() {
        return entityManager.createQuery("from CategoriaCurso", CategoriaCurso.class).getResultList();
    }

    @Transactional
    public CategoriaCurso inserir(CategoriaCurso categoriaCurso) {
        entityManager.persist(categoriaCurso);
        return categoriaCurso;
    }

    public List<CategoriaCurso> obterPorNome(String nome) {
        String jpql = "select c from CategoriaCurso c where c.nome like :nome";
        TypedQuery<CategoriaCurso> query = entityManager.createQuery(jpql, CategoriaCurso.class);
        query.setParameter("nome", "%" + nome + "%");
        return query.getResultList();
    }

    @Transactional
    public CategoriaCurso editar(CategoriaCurso categoriaCurso) {
        return entityManager.merge(categoriaCurso);
    }

    @Transactional
    public void excluir(Integer id) {
        CategoriaCurso categoriaCurso = entityManager.find(CategoriaCurso.class, id);
        if (categoriaCurso != null) {
            entityManager.remove(categoriaCurso);
        }
    }

    @Transactional
    public void excluir(CategoriaCurso categoriaCurso) {
        entityManager.remove(entityManager.merge(categoriaCurso));
    }
}